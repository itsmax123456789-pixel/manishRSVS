﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Backend.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Clients",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", nullable: false),
                    Logo = table.Column<string>(type: "TEXT", nullable: false),
                    IsActive = table.Column<bool>(type: "INTEGER", nullable: false),
                    DisplayOrder = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clients", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "HomeContents",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Title = table.Column<string>(type: "TEXT", nullable: false),
                    Description = table.Column<string>(type: "TEXT", nullable: false),
                    MediaUrl = table.Column<string>(type: "TEXT", nullable: false),
                    Type = table.Column<string>(type: "TEXT", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "TEXT", nullable: false),
                    IsActive = table.Column<bool>(type: "INTEGER", nullable: false),
                    DisplayOrder = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HomeContents", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Clients",
                columns: new[] { "Id", "DisplayOrder", "IsActive", "Logo", "Name" },
                values: new object[,]
                {
                    { 1, 1, true, "https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=400&h=300&fit=crop", "National Highways Authority" },
                    { 2, 2, true, "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=400&h=300&fit=crop", "State Infrastructure Corporation" },
                    { 3, 3, true, "https://images.unsplash.com/photo-1460472178825-e5240623afd5?w=400&h=300&fit=crop", "Metro Rail Development" },
                    { 4, 4, true, "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=400&h=300&fit=crop", "Urban Development Authority" },
                    { 5, 5, true, "https://images.unsplash.com/photo-1497366216548-37526070297c?w=400&h=300&fit=crop", "Construction Consortium" },
                    { 6, 6, true, "https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=400&h=300&fit=crop", "Infrastructure Solutions Ltd" }
                });

            migrationBuilder.InsertData(
                table: "HomeContents",
                columns: new[] { "Id", "CreatedDate", "Description", "DisplayOrder", "IsActive", "MediaUrl", "Title", "Type" },
                values: new object[,]
                {
                    { 1, new DateTime(2025, 12, 5, 23, 17, 9, 9, DateTimeKind.Local).AddTicks(6458), "Our in-house laboratory is ISO/IEC 17025:2017 certified for advanced geotechnical and material testing", 1, true, "https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=1200&h=600&fit=crop", "NABL Accredited Laboratory", "image" },
                    { 2, new DateTime(2025, 12, 5, 23, 17, 9, 9, DateTimeKind.Local).AddTicks(6465), "State-of-the-art field investigations using UAVs, DGPS, and Total Station for precision mapping", 2, true, "https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=1200&h=600&fit=crop", "Drone & DGPS Survey", "image" },
                    { 3, new DateTime(2025, 12, 5, 23, 17, 9, 9, DateTimeKind.Local).AddTicks(6470), "Led by IIT/NIT alumni, our professionals set standards in geotechnical, structural, and environmental engineering", 3, true, "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=1200&h=600&fit=crop", "Expert Team", "image" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Clients");

            migrationBuilder.DropTable(
                name: "HomeContents");
        }
    }
}
