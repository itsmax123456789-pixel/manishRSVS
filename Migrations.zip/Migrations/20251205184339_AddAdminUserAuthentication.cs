﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Backend.Migrations
{
    /// <inheritdoc />
    public partial class AddAdminUserAuthentication : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AdminUsers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Username = table.Column<string>(type: "TEXT", nullable: false),
                    PasswordHash = table.Column<string>(type: "TEXT", nullable: false),
                    Email = table.Column<string>(type: "TEXT", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "TEXT", nullable: false),
                    LastLoginDate = table.Column<DateTime>(type: "TEXT", nullable: true),
                    IsActive = table.Column<bool>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AdminUsers", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "AdminUsers",
                columns: new[] { "Id", "CreatedDate", "Email", "IsActive", "LastLoginDate", "PasswordHash", "Username" },
                values: new object[] { 1, new DateTime(2025, 12, 6, 0, 13, 38, 761, DateTimeKind.Local).AddTicks(7078), "admin@rsvs.com", true, null, "$2a$11$xvYQT5OzD5VKJZzLlJEQWuKlvNHJ8R5gVYqJbUJ3fYLZzPn6hqKY6", "admin" });

            migrationBuilder.UpdateData(
                table: "HomeContents",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2025, 12, 6, 0, 13, 38, 761, DateTimeKind.Local).AddTicks(6895));

            migrationBuilder.UpdateData(
                table: "HomeContents",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2025, 12, 6, 0, 13, 38, 761, DateTimeKind.Local).AddTicks(6899));

            migrationBuilder.UpdateData(
                table: "HomeContents",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2025, 12, 6, 0, 13, 38, 761, DateTimeKind.Local).AddTicks(6902));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AdminUsers");

            migrationBuilder.UpdateData(
                table: "HomeContents",
                keyColumn: "Id",
                keyValue: 1,
                column: "CreatedDate",
                value: new DateTime(2025, 12, 5, 23, 17, 9, 9, DateTimeKind.Local).AddTicks(6458));

            migrationBuilder.UpdateData(
                table: "HomeContents",
                keyColumn: "Id",
                keyValue: 2,
                column: "CreatedDate",
                value: new DateTime(2025, 12, 5, 23, 17, 9, 9, DateTimeKind.Local).AddTicks(6465));

            migrationBuilder.UpdateData(
                table: "HomeContents",
                keyColumn: "Id",
                keyValue: 3,
                column: "CreatedDate",
                value: new DateTime(2025, 12, 5, 23, 17, 9, 9, DateTimeKind.Local).AddTicks(6470));
        }
    }
}
