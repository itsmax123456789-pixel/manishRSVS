using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _configuration;

        public AuthController(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        // POST: api/Auth/login
        [HttpPost("login")]
        public async Task<ActionResult<LoginResponse>> Login(LoginRequest request)
        {
            // Find the admin user
            var adminUser = await _context.AdminUsers
                .FirstOrDefaultAsync(u => u.Username == request.Username && u.IsActive);

            if (adminUser == null)
            {
                return Unauthorized(new { message = "Invalid username or password" });
            }

            // Verify password
            if (!BCrypt.Net.BCrypt.Verify(request.Password, adminUser.PasswordHash))
            {
                return Unauthorized(new { message = "Invalid username or password" });
            }

            // Update last login date
            adminUser.LastLoginDate = DateTime.Now;
            await _context.SaveChangesAsync();

            // Generate JWT token
            var token = GenerateJwtToken(adminUser);

            return Ok(new LoginResponse
            {
                Token = token,
                Username = adminUser.Username,
                Email = adminUser.Email,
                Expiration = DateTime.UtcNow.AddHours(24)
            });
        }

        private string GenerateJwtToken(AdminUser user)
        {
            var jwtSettings = _configuration.GetSection("JwtSettings");
            var secretKey = jwtSettings["SecretKey"] ?? throw new InvalidOperationException("JWT SecretKey not configured");
            var issuer = jwtSettings["Issuer"] ?? "RSVS";
            var audience = jwtSettings["Audience"] ?? "RSVSClient";

            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Email, user.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                expires: DateTime.UtcNow.AddHours(24),
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        // Optional: Endpoint to verify token
        [HttpGet("verify")]
        public IActionResult VerifyToken()
        {
            var username = User.FindFirst(ClaimTypes.Name)?.Value;
            if (username != null)
            {
                return Ok(new { message = "Token is valid", username });
            }
            return Unauthorized(new { message = "Invalid token" });
        }

        // Temporary: Test password hashing (REMOVE IN PRODUCTION!)
        [HttpGet("test-password")]
        public async Task<IActionResult> TestPassword([FromQuery] string password = "Admin@123")
        {
            var hash = BCrypt.Net.BCrypt.HashPassword(password);
            var verify = BCrypt.Net.BCrypt.Verify(password, hash);
            
            // Get current admin user
            var admin = await _context.AdminUsers.FirstOrDefaultAsync(u => u.Username == "admin");
            var currentHashWorks = admin != null ? BCrypt.Net.BCrypt.Verify(password, admin.PasswordHash) : false;
            
            return Ok(new { 
                password,
                newHash = hash,
                verifyNewHash = verify,
                currentHashWorks,
                currentHash = admin?.PasswordHash
            });
        }

        // Temporary: Reset admin password (REMOVE IN PRODUCTION!)
        [HttpPost("reset-admin-password")]
        public async Task<IActionResult> ResetAdminPassword([FromBody] string newPassword = "Admin@123")
        {
            var admin = await _context.AdminUsers.FirstOrDefaultAsync(u => u.Username == "admin");
            if (admin == null)
            {
                return NotFound(new { message = "Admin user not found" });
            }

            admin.PasswordHash = BCrypt.Net.BCrypt.HashPassword(newPassword);
            await _context.SaveChangesAsync();

            return Ok(new { message = $"Password reset successfully for {admin.Username}", newHash = admin.PasswordHash });
        }
    }
}
