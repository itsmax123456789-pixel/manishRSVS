using Backend.Data;
using Backend.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeContentController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public HomeContentController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/HomeContent
        [HttpGet]
        public async Task<ActionResult<IEnumerable<HomeContent>>> GetHomeContents()
        {
            return await _context.HomeContents
                .Where(h => h.IsActive)
                .OrderBy(h => h.DisplayOrder)
                .ToListAsync();
        }

        // GET: api/HomeContent/5
        [HttpGet("{id}")]
        public async Task<ActionResult<HomeContent>> GetHomeContent(int id)
        {
            var homeContent = await _context.HomeContents.FindAsync(id);

            if (homeContent == null)
            {
                return NotFound();
            }

            return homeContent;
        }

        // POST: api/HomeContent
        [HttpPost]
        [Authorize] // Admin only
        public async Task<ActionResult<HomeContent>> PostHomeContent(HomeContent homeContent)
        {
            _context.HomeContents.Add(homeContent);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetHomeContent), new { id = homeContent.Id }, homeContent);
        }

        // PUT: api/HomeContent/5
        [HttpPut("{id}")]
        [Authorize] // Admin only
        public async Task<IActionResult> PutHomeContent(int id, HomeContent homeContent)
        {
            if (id != homeContent.Id)
            {
                return BadRequest();
            }

            _context.Entry(homeContent).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!HomeContentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/HomeContent/5
        [HttpDelete("{id}")]
        [Authorize] // Admin only
        public async Task<IActionResult> DeleteHomeContent(int id)
        {
            var homeContent = await _context.HomeContents.FindAsync(id);
            if (homeContent == null)
            {
                return NotFound();
            }

            _context.HomeContents.Remove(homeContent);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool HomeContentExists(int id)
        {
            return _context.HomeContents.Any(e => e.Id == id);
        }
    }
}
