const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Path to news data file
const NEWS_DATA_FILE = path.join(__dirname, 'data', 'news.json');

// Ensure data directory exists
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir);
}

// Initialize news data file if it doesn't exist
if (!fs.existsSync(NEWS_DATA_FILE)) {
  const initialData = {
    news: [
      {
        id: 1,
        title: 'New Bridge Construction Project Completed',
        description: 'Successfully completed the Riverside Bridge connecting East and West districts',
        date: '2024-12-01',
        type: 'image',
        mediaUrl: 'https://images.unsplash.com/photo-1587293852726-70cdb56c2866?w=1200&h=600&fit=crop'
      },
      {
        id: 2,
        title: 'Sustainable Building Initiative Launched',
        description: 'Pioneering eco-friendly construction methods for urban development',
        date: '2024-11-28',
        type: 'image',
        mediaUrl: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=1200&h=600&fit=crop'
      },
      {
        id: 3,
        title: 'Highway Expansion Project in Progress',
        description: 'Major infrastructure improvement to reduce traffic congestion',
        date: '2024-11-25',
        type: 'image',
        mediaUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1200&h=600&fit=crop'
      }
    ]
  };
  fs.writeFileSync(NEWS_DATA_FILE, JSON.stringify(initialData, null, 2));
}

// Helper function to read news data
function readNewsData() {
  const data = fs.readFileSync(NEWS_DATA_FILE, 'utf8');
  return JSON.parse(data);
}

// Helper function to write news data
function writeNewsData(data) {
  fs.writeFileSync(NEWS_DATA_FILE, JSON.stringify(data, null, 2));
}

// GET all news
app.get('/api/news', (req, res) => {
  try {
    const data = readNewsData();
    res.json(data.news);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch news' });
  }
});

// GET single news item
app.get('/api/news/:id', (req, res) => {
  try {
    const data = readNewsData();
    const newsItem = data.news.find(item => item.id === parseInt(req.params.id));
    
    if (!newsItem) {
      return res.status(404).json({ error: 'News item not found' });
    }
    
    res.json(newsItem);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch news item' });
  }
});

// POST create new news item
app.post('/api/news', (req, res) => {
  try {
    const data = readNewsData();
    
    // Validation
    const { title, description, date, type, mediaUrl } = req.body;
    
    if (!title || !description || !date || !type || !mediaUrl) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    if (!['image', 'video'].includes(type)) {
      return res.status(400).json({ error: 'Type must be either "image" or "video"' });
    }
    
    // Create new news item
    const newId = data.news.length > 0 ? Math.max(...data.news.map(n => n.id)) + 1 : 1;
    const newNewsItem = {
      id: newId,
      title: title.trim(),
      description: description.trim(),
      date: date,
      type: type,
      mediaUrl: mediaUrl.trim()
    };
    
    data.news.unshift(newNewsItem); // Add to beginning
    writeNewsData(data);
    
    res.status(201).json(newNewsItem);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create news item' });
  }
});

// PUT update news item
app.put('/api/news/:id', (req, res) => {
  try {
    const data = readNewsData();
    const index = data.news.findIndex(item => item.id === parseInt(req.params.id));
    
    if (index === -1) {
      return res.status(404).json({ error: 'News item not found' });
    }
    
    const { title, description, date, type, mediaUrl } = req.body;
    
    if (!title || !description || !date || !type || !mediaUrl) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    if (!['image', 'video'].includes(type)) {
      return res.status(400).json({ error: 'Type must be either "image" or "video"' });
    }
    
    data.news[index] = {
      id: data.news[index].id,
      title: title.trim(),
      description: description.trim(),
      date: date,
      type: type,
      mediaUrl: mediaUrl.trim()
    };
    
    writeNewsData(data);
    res.json(data.news[index]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update news item' });
  }
});

// DELETE news item
app.delete('/api/news/:id', (req, res) => {
  try {
    const data = readNewsData();
    const index = data.news.findIndex(item => item.id === parseInt(req.params.id));
    
    if (index === -1) {
      return res.status(404).json({ error: 'News item not found' });
    }
    
    data.news.splice(index, 1);
    writeNewsData(data);
    
    res.json({ message: 'News item deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete news item' });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'News API is running' });
});

// Start server
app.listen(PORT, () => {
  console.log(`News API server running on http://localhost:${PORT}`);
  console.log(`API endpoints:`);
  console.log(`  GET    /api/news       - Get all news`);
  console.log(`  GET    /api/news/:id   - Get single news item`);
  console.log(`  POST   /api/news       - Create news item`);
  console.log(`  PUT    /api/news/:id   - Update news item`);
  console.log(`  DELETE /api/news/:id   - Delete news item`);
});
