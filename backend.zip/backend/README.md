# Backend API for Civil Engineering Website

This is a simple REST API for managing news items on the civil engineering website.

## Setup

1. Install dependencies:
```bash
npm install
```

2. Start the server:
```bash
npm start
```

For development with auto-reload:
```bash
npm run dev
```

The server will run on `http://localhost:3000`

## API Endpoints

### Get All News
```
GET /api/news
```

### Get Single News Item
```
GET /api/news/:id
```

### Create News Item
```
POST /api/news
Content-Type: application/json

{
  "title": "News Title",
  "description": "News description",
  "date": "2024-12-04",
  "type": "image",  // or "video"
  "mediaUrl": "https://example.com/image.jpg"
}
```

### Update News Item
```
PUT /api/news/:id
Content-Type: application/json

{
  "title": "Updated Title",
  "description": "Updated description",
  "date": "2024-12-04",
  "type": "image",
  "mediaUrl": "https://example.com/image.jpg"
}
```

### Delete News Item
```
DELETE /api/news/:id
```

### Health Check
```
GET /api/health
```

## Data Storage

News data is stored in `data/news.json` file. You can manually edit this file to update news items.

## Security Features

- CORS enabled for frontend access
- Input validation for all POST/PUT requests
- Sanitized user inputs (trimmed strings)
- Type checking for media type (image/video only)

## For Production

For production deployment, consider adding:
- Authentication/Authorization
- HTTPS
- Rate limiting
- Database instead of JSON file
- Environment variables for configuration
- Logging system
- Error monitoring
