// src/app/services/home-content.service.ts

// Import Injectable decorator - marks this class as a service that can be injected
import { Injectable } from '@angular/core';

// Import HttpClient - Angular's service for making HTTP requests (GET, POST, PUT, DELETE)
import { HttpClient } from '@angular/common/http';

// Import Observable - represents a stream of data that arrives over time
import { Observable } from 'rxjs';

// **Interface Definition (Must match the C# Model in Backend)**
// Export interface so other components can use this type definition
// This interface defines the structure of home carousel content from the API
export interface HomeContent {
  id: number;              // Unique identifier from database
  title: string;           // Carousel item title/heading
  description: string;     // Detailed description text
  mediaUrl: string;        // URL to image or video file (corresponds to MediaUrl in C# model)
  type: 'image' | 'video'; // Media type - can only be 'image' OR 'video'
  createdDate: string;     // ISO date string when item was created
  isActive: boolean;       // Whether item is active/visible
  displayOrder: number;    // Order number for sorting items
}

// @Injectable decorator - tells Angular this class can be injected as a dependency
// providedIn: 'root' - creates single instance shared across entire application
@Injectable({
  providedIn: 'root'
})
export class HomeContentService {
  // Use a constant for the base URL. If you deploy, this will need to be changed.
  // This points to your .NET Web API backend running locally
  // Private property storing the backend API endpoint URL
  private apiUrl = 'http://localhost:5108/api/HomeContent';

  // Constructor - runs when service is created
  // Dependency Injection: Angular automatically injects HttpClient instance
  // HttpClient is required to communicate with the API
  constructor(private http: HttpClient) { }

  /**
   * Fetches all home carousel content items.
   * This sends an HTTP GET request to the .NET API controller, 
   * which in turn reads the data from the SQLite database table.
   * @returns An Observable of an array of HomeContent objects
   */
  getHomeContents(): Observable<HomeContent[]> {
    // Makes HTTP GET request to API endpoint
    // <HomeContent[]> tells TypeScript what type of data to expect
    // The HTTP request is what calls the backend
    return this.http.get<HomeContent[]>(this.apiUrl);
  }

  // **Other CRUD operations for interacting with the backend:**

  /**
   * Fetches a single home content item by its ID.
   * @param id - the unique identifier of the item
   * @returns Observable that emits a single HomeContent object
   */
  getHomeContent(id: number): Observable<HomeContent> {
    // Makes HTTP GET request to /api/HomeContent/{id}
    // Template literal ${} inserts the id value into the URL
    return this.http.get<HomeContent>(`${this.apiUrl}/${id}`);
  }

  /**
   * Creates a new home content item (Admin function).
   * @param content - the new HomeContent object to create
   * @returns Observable that emits the created HomeContent with generated ID
   */
  createHomeContent(content: HomeContent): Observable<HomeContent> {
    // Makes HTTP POST request with content object as request body
    // Backend will save to database and return the saved object
    return this.http.post<HomeContent>(this.apiUrl, content);
  }

  /**
   * Updates an existing home content item (Admin function).
   * @param id - identifier of item to update
   * @param content - updated data
   * @returns Observable that emits void (no return data)
   */
  updateHomeContent(id: number, content: HomeContent): Observable<void> {
    // Makes HTTP PUT request to /api/HomeContent/{id} with updated content
    // Backend will update the database record
    return this.http.put<void>(`${this.apiUrl}/${id}`, content);
  }

  /**
   * Deletes a home content item (Admin function).
   * @param id - identifier of item to delete
   * @returns Observable that emits void (no return data)
   */
  deleteHomeContent(id: number): Observable<void> {
    // Makes HTTP DELETE request to /api/HomeContent/{id}
    // Backend will remove the record from database
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
