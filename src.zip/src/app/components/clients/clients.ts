import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClientService, Client } from '../../services/client.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-clients',
  imports: [CommonModule],
  templateUrl: './clients.html',
  styleUrl: './clients.css',
})
export class Clients implements OnInit, OnDestroy {
  clients: Client[] = [];
  displayedClients: Client[] = [];
  private rotationInterval: any;
  private currentIndex: number = 0;
  cardFading: boolean[] = [false, false, false];
  private clientSubscription!: Subscription;

  constructor(private clientService: ClientService) {}

  ngOnInit(): void {
    // Load clients from API
    this.loadClients();
  }

  private loadClients(): void {
    this.clientSubscription = this.clientService.getClients().subscribe({
      next: (data: Client[]) => {
        this.clients = data;
        
        // Initialize with first 3 clients
        if (this.clients.length >= 3) {
          this.displayedClients = [
            this.clients[0],
            this.clients[1],
            this.clients[2]
          ];
          this.currentIndex = 3; // Next client to show
        } else {
          this.displayedClients = [...this.clients];
        }
        
        // Start rotation every 3 seconds - slides left so all clients go through center
        this.rotationInterval = setInterval(() => {
          this.rotateClients();
        }, 3000);
      },
      error: (error) => {
        console.error('Error loading clients:', error);
      }
    });
  }

  private rotateClients(): void {
    if (this.clients.length <= 3) return; // No rotation needed if 3 or fewer clients
    
    // Change only one card at a time - rotate which position changes
    const cardIndex = this.currentIndex % 3; // Cycles through 0, 1, 2
    
    // Start fade out on only one card
    this.cardFading[cardIndex] = true;
    
    // Wait for fade out animation
    setTimeout(() => {
      // Get the next client in sequence
      const nextClientIndex = (this.currentIndex + 3) % this.clients.length;
      
      // Replace only the fading card with the next client
      this.displayedClients[cardIndex] = this.clients[nextClientIndex];
      this.displayedClients = [...this.displayedClients]; // Trigger change detection
      
      // Move to next client for next rotation
      this.currentIndex++;
      
      // Fade the card back in
      setTimeout(() => {
        this.cardFading[cardIndex] = false;
      }, 50);
    }, 300);
  }

  ngOnDestroy(): void {
    if (this.clientSubscription) {
      this.clientSubscription.unsubscribe();
    }
    if (this.rotationInterval) {
      clearInterval(this.rotationInterval);
    }
  }
}
