
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from '../../services/auth.service';
import { HomeContentService, HomeContent } from '../../services/home-content.service';
import { ClientService, Client } from '../../services/client.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  // Tabs (only home and clients remain)
  activeTab: 'home' | 'clients' = 'home';

  // Home Content
  homeContents: HomeContent[] = [];
  showForm = false;
  editMode = false;
  currentContent: Partial<HomeContent> = {
    title: '',
    description: '',
    mediaUrl: '',
    type: 'image',
    isActive: true,
    displayOrder: 1
  };

  // Clients
  clients: Client[] = [];
  showClientForm = false;
  editClientMode = false;
  currentClient: Partial<Client> = {
    name: '',
    logo: '',
    isActive: true,
    displayOrder: 1
  };

  // Common
  currentUser: { username: string; email: string } | null = null;
  isLoading = false;
  errorMessage = '';
  successMessage = '';

  constructor(
    private authService: AuthService,
    private homeContentService: HomeContentService,
    private clientService: ClientService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
    if (!this.authService.isLoggedIn()) {
      this.router.navigate(['/admin/login']);
      return;
    }
    this.loadHomeContents();
    this.loadClients();
  }

  switchTab(tab: 'home' | 'clients'): void {
    this.activeTab = tab;
    this.closeForm();
    this.closeClientForm();
  }

  // ------- Home Content -------
  loadHomeContents(): void {
    this.isLoading = true;
    this.homeContentService.getHomeContents().subscribe({
      next: (contents) => {
        this.homeContents = contents;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading content', error);
        this.errorMessage = 'Failed to load content';
        this.isLoading = false;
      }
    });
  }

  openAddForm(): void {
    this.showForm = true;
    this.editMode = false;
    this.currentContent = {
      title: '',
      description: '',
      mediaUrl: '',
      type: 'image',
      isActive: true,
      displayOrder: this.homeContents.length + 1
    };
  }

  openEditForm(content: HomeContent): void {
    this.showForm = true;
    this.editMode = true;
    this.currentContent = { ...content };
  }

  closeForm(): void {
    this.showForm = false;
    this.currentContent = {
      title: '',
      description: '',
      mediaUrl: '',
      type: 'image',
      isActive: true,
      displayOrder: 1
    };
  }

  saveContent(): void {
    this.errorMessage = '';
    this.successMessage = '';

    if (this.editMode && this.currentContent.id) {
      // Update existing content
      this.homeContentService.updateHomeContent(
        this.currentContent.id,
        this.currentContent as HomeContent
      ).subscribe({
        next: () => {
          this.successMessage = 'Content updated successfully!';
          this.loadHomeContents();
          this.closeForm();
          setTimeout(() => (this.successMessage = ''), 3000);
        },
        error: (error) => {
          console.error('Error updating content', error);
          this.errorMessage = 'Failed to update content. Make sure you are logged in.';
        }
      });
    } else {
      // Create new content
      this.homeContentService.createHomeContent(
        this.currentContent as HomeContent
      ).subscribe({
        next: () => {
          this.successMessage = 'Content created successfully!';
          this.loadHomeContents();
          this.closeForm();
          setTimeout(() => (this.successMessage = ''), 3000);
        },
        error: (error) => {
          console.error('Error creating content', error);
          this.errorMessage = 'Failed to create content. Make sure you are logged in.';
        }
      });
    }
  }

  deleteContent(id: number): void {
    if (confirm('Are you sure you want to delete this content?')) {
      this.homeContentService.deleteHomeContent(id).subscribe({
        next: () => {
          this.successMessage = 'Content deleted successfully!';
          this.loadHomeContents();
          setTimeout(() => (this.successMessage = ''), 3000);
        },
        error: (error) => {
          console.error('Error deleting content', error);
          this.errorMessage = 'Failed to delete content. Make sure you are logged in.';
        }
      });
    }
  }

  // ------- Clients -------
  loadClients(): void {
    this.isLoading = true;
    this.clientService.getClients().subscribe({
      next: (clients) => {
        this.clients = clients;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading clients', error);
        this.errorMessage = 'Failed to load clients';
        this.isLoading = false;
      }
    });
  }

  openAddClientForm(): void {
    this.showClientForm = true;
    this.editClientMode = false;
    this.currentClient = {
      name: '',
      logo: '',
      isActive: true,
      displayOrder: this.clients.length + 1
    };
  }

  openEditClientForm(client: Client): void {
    this.showClientForm = true;
    this.editClientMode = true;
    this.currentClient = { ...client };
  }

  closeClientForm(): void {
    this.showClientForm = false;
    this.currentClient = {
      name: '',
      logo: '',
      isActive: true,
      displayOrder: 1
    };
  }

  saveClient(): void {
    this.errorMessage = '';
    this.successMessage = '';

    if (this.editClientMode && this.currentClient.id) {
      // Update existing client
      this.clientService.updateClient(
        this.currentClient.id,
        this.currentClient as Client
      ).subscribe({
        next: () => {
          this.successMessage = 'Client updated successfully!';
          this.loadClients();
          this.closeClientForm();
          setTimeout(() => (this.successMessage = ''), 3000);
        },
        error: (error) => {
          console.error('Error updating client', error);
          this.errorMessage = 'Failed to update client. Make sure you are logged in.';
        }
      });
    } else {
      // Create new client
      this.clientService.createClient(
        this.currentClient as Client
      ).subscribe({
        next: () => {
          this.successMessage = 'Client created successfully!';
          this.loadClients();
          this.closeClientForm();
          setTimeout(() => (this.successMessage = ''), 3000);
        },
        error: (error) => {
          console.error('Error creating client', error);
          this.errorMessage = 'Failed to create client. Make sure you are logged in.';
        }
      });
    }
  }

  deleteClient(id: number): void {
    if (confirm('Are you sure you want to delete this client?')) {
      this.clientService.deleteClient(id).subscribe({
        next: () => {
          this.successMessage = 'Client deleted successfully!';
          this.loadClients();
          setTimeout(() => (this.successMessage = ''), 3000);
        },
        error: (error) => {
          console.error('Error deleting client', error);
          this.errorMessage = 'Failed to delete client. Make sure you are logged in.';
        }
      });
    }
  }

  // ------- Auth -------
  logout(): void {
    this.authService.logout();
    this.router.navigate(['/admin/login']);
   }
  }