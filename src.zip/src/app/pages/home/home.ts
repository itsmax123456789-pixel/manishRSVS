// Import Component decorator to create an Angular component
// Import OnInit interface - allows component to execute code when initialized
// Import OnDestroy interface - allows cleanup code when component is destroyed
import { Component, OnInit, OnDestroy } from '@angular/core';

// Import CommonModule - provides common Angular directives like *ngIf, *ngFor
import { CommonModule } from '@angular/common';

// Import RouterLink - enables navigation between routes in the application

// Import the Clients component to display client logos on the home page
import { Clients } from '../../components/clients/clients';

// Import the service that communicates with the backend API
// HomeContentService - service class with HTTP methods
// HomeContent - interface defining the shape of data from API
import { HomeContentService, HomeContent } from '../../services/home-content.service';

// Import Subscription to manage API call cleanup
import { Subscription } from 'rxjs';

// @Component decorator - marks this class as an Angular component
@Component({
  selector: 'app-home',  // HTML tag name to use this component: <app-home></app-home>
  imports: [CommonModule, Clients],  // Standalone component imports
  templateUrl: './home.html',  // Path to the HTML template file
  styleUrl: './home.css',      // Path to the CSS styling file
})
// Export the class so it can be imported elsewhere
// Implements OnInit - must have ngOnInit() method
// Implements OnDestroy - must have ngOnDestroy() method
export class Home implements OnInit, OnDestroy {
  
  // Array to store all carousel items from API, initially empty
  carouselItems: HomeContent[] = [];
  
  // Index of currently displayed slide (starts at 0 = first slide)
  currentSlide = 0;
  
  // Variable to store the interval timer ID (private = only accessible in this class)
  // 'any' type because JavaScript intervals return a number ID
  private autoPlayInterval: any;

  // Subscription to manage the API call and prevent memory leaks
  private contentSubscription!: Subscription;

  // Constructor - runs once when component is created
  // Dependency Injection: Angular automatically provides HomeContentService instance
  // 'private' makes it accessible throughout the class as 'this.homeContentService'
  constructor(private homeContentService: HomeContentService) {}

  // **ngOnInit:** Initialization and Setup
  // ngOnInit - lifecycle hook that runs after component is initialized
  // This is where you typically load initial data
  ngOnInit(): void {
    this.loadHomeContent();  // Call method to fetch data from API (Data fetching)
    this.startAutoPlay();    // Start automatic slide rotation (Timer setup)
   
  }

  // Method to load carousel content from the backend API
  loadHomeContent(): void {
    // Call the service method to get data from API
    // Returns an Observable (stream of data)
    // Subscribe to the API call and store the subscription
    this.contentSubscription = this.homeContentService.getHomeContents().subscribe({
      // 'next' - callback function executed when API returns successful response
      next: (data: HomeContent[]) => {
        // Store API data directly in carouselItems
        this.carouselItems = data;
      },
      // 'error' - callback function executed if API call fails
      error: (error) => {
        // This will now only show errors if the API fails, not CORS
        // Log the error to browser console for debugging
        console.error('Error loading home content:', error);
      }
    });
  }

  // **ngOnDestroy:** Cleanup
  // ngOnDestroy - lifecycle hook that runs just before component is destroyed
  // Used for cleanup to prevent memory leaks
  ngOnDestroy(): void {
    // 1. Crucial: Stop the API subscription stream to prevent memory leaks
    if (this.contentSubscription) {
      this.contentSubscription.unsubscribe();
    }
    // 2. Stop the JavaScript interval timer
    this.stopAutoPlay();
  }

  // Method to start automatic slide rotation
  startAutoPlay(): void {
    // setInterval - JavaScript function that repeatedly executes code
    // First parameter: arrow function to execute
    // Second parameter: time in milliseconds (3000ms = 3 seconds)
    this.autoPlayInterval = setInterval(() => {
      this.nextSlide();  // Move to next slide every 3 seconds
    }, 5000);
  }

  // Method to stop the automatic slide rotation
  stopAutoPlay(): void {
    // Check if interval exists (not null/undefined)
    if (this.autoPlayInterval) {
      // clearInterval - JavaScript function to stop a repeating timer
      clearInterval(this.autoPlayInterval);
    }
  }

  // Method to advance to the next slide
  nextSlide(): void {
    // Calculate next slide index using modulo operator (%)
    // Example: if currentSlide=2 and length=3: (2+1)%3 = 0 (wraps back to start)
    // This creates infinite loop: 0 -> 1 -> 2 -> 0 -> 1 -> 2...
    this.currentSlide = (this.currentSlide + 1) % this.carouselItems.length;
  }

  // Method to go back to the previous slide
  previousSlide(): void {
    // Ternary operator: condition ? valueIfTrue : valueIfFalse
    // If at first slide (0), go to last slide (length-1)
    // Otherwise, just subtract 1
    this.currentSlide = this.currentSlide === 0 
      ? this.carouselItems.length - 1  // Wrap to end
      : this.currentSlide - 1;         // Go back one
  }

  // Method to jump to a specific slide when user clicks indicator dot
  goToSlide(index: number): void {
    this.currentSlide = index;  // Set slide to clicked index
    this.stopAutoPlay();        // Stop current autoplay timer
    this.startAutoPlay();       // Restart autoplay timer (resets the 5-second countdown)
  }
}
