import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface TeamMember {
  id: number;
  name: string;
  role: string;
  bio: string;
  experience: number;
  imageUrl: string;
}

@Component({
  selector: 'app-team',
  imports: [CommonModule],
  templateUrl: './team.html',
  styleUrl: './team.css',
})
export class Team {
  // PLACEHOLDER DATA - Replace with actual team member information
  teamMembers: TeamMember[] = [
    {
      id: 1,
      name: 'John Smith',
      role: 'Chief Engineer',
      bio: 'Leading structural engineering projects with expertise in bridge and high-rise construction.',
      experience: 20,
      imageUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop'
    },
    {
      id: 2,
      name: 'Sarah Johnson',
      role: 'Project Manager',
      bio: 'Specialized in large-scale infrastructure projects and team coordination.',
      experience: 15,
      imageUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop'
    },
    {
      id: 3,
      name: 'Michael Chen',
      role: 'Senior Structural Engineer',
      bio: 'Expert in seismic design and sustainable building practices.',
      experience: 12,
      imageUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop'
    },
    {
      id: 4,
      name: 'Emily Rodriguez',
      role: 'Geotechnical Engineer',
      bio: 'Specialized in soil mechanics and foundation engineering.',
      experience: 10,
      imageUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop'
    },
    {
      id: 5,
      name: 'David Williams',
      role: 'Transportation Engineer',
      bio: 'Expert in highway design and traffic management systems.',
      experience: 14,
      imageUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&h=400&fit=crop'
    },
    {
      id: 6,
      name: 'Lisa Anderson',
      role: 'Environmental Engineer',
      bio: 'Focused on sustainable practices and environmental impact assessments.',
      experience: 8,
      imageUrl: 'https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=400&h=400&fit=crop'
    }
  ];
}
